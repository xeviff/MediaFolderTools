1. Descomprimir carpeta MediaFolder_Tools donde se desee.
2. Ejecutar acceso directo "MediaFolder_Tools". Posiblemente pueda requerir instalación adicional de .NET Framework (en tal caso, windows le advertirá).
3. Introduce tu usuario y contraseña proporcionado. Asegurarse que se está conectado a internet.

VERSIÓN 3.0
Cambios: 
* Bugfix escaneo nivel infinito árbol de carpetas. Ahora empieza por el fondo y va subiendo.
* Adición lista errores en la interfície
* Adición login (para que no todo el mundo pueda ejecutar scripts masivos)